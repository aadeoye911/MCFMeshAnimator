
#include <Eigen/Core>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/readOBJ.h>
#include <thread>
#include <chrono>
#include "remeshing.h"
#include "medial_axis_transform.h"
#include "mcf_skeleton.h"
#include "utils.h"

int main() {
    igl::opengl::glfw::Viewer viewer;
    
    Eigen::MatrixXd V;
    Eigen::MatrixXi F;

    std::string test_mesh = "../data/test_meshes/test_remeshed.obj";
    if (!igl::readOBJ(test_mesh, V, F)) {
        std::cerr << "Failed to load mesh from " << test_mesh << std::endl;
        return -1;  // Exit if the mesh cannot be loaded
    }

    // Check if the mesh is watertight
    if (!utils::is_watertight(F)) {
        std::cerr << "Input mesh must be watertight" << std::endl;
        return -1;  // Exit if the mesh is not watertight
    }

    viewer.data().set_mesh(V, F);
    viewer.data().set_face_based(true);
    viewer.launch_init();
    viewer.data().set_colors(Eigen::RowVector3d(1, 0, 0));
    viewer.core().background_color.setOnes(); // Set background to white for visibility

    viewer.data().show_faces = true;
    viewer.data().show_lines = true; // Hide wireframe

    // Perform remeshing and other processes
    // Remeshing remeshing(V, F);
    // remeshing.remesh();

    // Setup the Medial Axis Transform
    MedialAxisTransform mat(V, F);
    mat.compute();
    
    // Setup MCF Skeleton
    MCFSkeleton mcf(mat.getVertices(), mat.getFaces(), mat.getMedialPoles());

    // int skeleton_view = viewer.append_mesh();
    // // viewer.data(skeleton_view).set_colors(Eigen::RowVector3d(1, 0, 0)); // Red color for MCF skeleton
    // // viewer.data(skeleton_view).set_face_based(true);
    // viewer.data(skeleton_view).show_lines = false;  // Hide wireframe for MCF skeleton

    // while (mcf.getIteration() < max_iterations && iteration < max_iterations) {
    mcf.skeletonize(10);  // Perform one iteration at a time

    // Update the viewer with the new MCF skeleton
    viewer.data().set_mesh(mcf.getVertices(), mcf.getFaces());
    
    // Final display with MCF skeleton overlaid on the original transparent mesh
    viewer.launch();  // Keep the viewer open

    return 0;
}