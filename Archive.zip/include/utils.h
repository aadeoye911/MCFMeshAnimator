#pragma once

#include <iostream>
#include <stdexcept>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <functional>
#include <limits>
#include <set>
#include <Eigen/Core>
#include <Eigen/Sparse>
#include <igl/adjacency_matrix.h>
#include <igl/boundary_loop.h>
#include <igl/edge_flaps.h>
#include <igl/edge_lengths.h>
#include <igl/is_edge_manifold.h>
#include <igl/is_vertex_manifold.h>
#include <igl/parallel_for.h>
#include <igl/setdiff.h>
#include <igl/slice_mask.h>
#include <igl/unique.h>
#include <igl/unique_edge_map.h>
#include <igl/unique_rows.h>

using ArrayXb = Eigen::Array<bool, Eigen::Dynamic,1>;

namespace utils {
    
    /** \brief Perform edge splitting operation on batch of (non-adjacent) edges. */
    void split_non_adjacent_edges(Eigen::MatrixXd& V, Eigen::MatrixXi& F, Eigen::MatrixXi& uE, 
                            Eigen::MatrixXi& EF, Eigen::VectorXi& uE_batch, Eigen::MatrixXd& V_new);

    /** \brief Extract batch of non-adjacent edges from subset of edges. */
    void get_non_adjacent_edge_batch(Eigen::VectorXi& uE_indices, Eigen::MatrixXi& EF, Eigen::VectorXi& uE_batch);

    /** \brief Get the vertex indices for the neighborhood of a given edge. */
    void get_edge_neighborhood(int e, Eigen::MatrixXi& F, Eigen::MatrixXi& uE, 
                            Eigen::MatrixXi& EF, Eigen::MatrixXi& EI, Eigen::VectorXi& neighborhood);

    /** \brief Get the valences of vertices in a given mesh */
    void get_vertex_valences(const Eigen::MatrixXi& F, Eigen::VectorXi& valences);

    /** \brief Compute the midpoints of a subset of edges. */
    void get_edge_midpoints(Eigen::MatrixXd& V, Eigen::MatrixXi& uE, 
                           Eigen::VectorXi& uE_indices, Eigen::MatrixXd& midpoints);

    /** \brief Check if the mesh is watertight (i.e., no holes or gaps). */
    bool is_watertight(const Eigen::MatrixXi& F);

    void audit_topology_changes(const Eigen::MatrixXd& V_before, const Eigen::MatrixXd& V_after, 
                            const Eigen::MatrixXi& F_before, const Eigen::MatrixXi& F_after);

    /** \brief Cyclically permute vector shifting one position to the right */
    void rotate_vector(Eigen::RowVectorXi& vec);
    
    template <typename Comparator>
    void filter_edges_by_attribute(Eigen::MatrixXi& F, Eigen::MatrixXd &attribute, 
                                Comparator comp, double threshold, Eigen::VectorXi& uE_filt)
    { 
        Eigen::MatrixXi E, uE;
        Eigen::VectorXi EMAP;
        igl::unique_edge_map(F, E, uE, EMAP);

        // Flatten attribute matrix column wise to match order of half-edges in E
        Eigen::VectorXd attribute_flat = Eigen::Map<const Eigen::VectorXd>(attribute.data(), attribute.size());
        ArrayXb condition = attribute_flat.array().unaryExpr([&](double value) {
            return comp(value, threshold);
        });

        std::cout << "Number of directed edges filtered: " << condition.count() << std::endl;

        // Pre-allocate the output vector
        Eigen::VectorXi hE_filt;
        hE_filt.resize(condition.count());
        // Populate the output vector
        int he = 0;
        for (int i = 0; i < EMAP.size(); ++i) {
            if (condition[i]) {
                hE_filt[he++] = EMAP[i];
            }
        }
        igl::unique(hE_filt, uE_filt);
    }
}