#include <iostream>
#include <vector>
#include <limits>
#include <Eigen/Core>

// libigl includes
#include <igl/adjacency_list.h>
#include <igl/decimate.h>
#include <igl/decimate_trivial_callbacks.h>
#include <igl/edge_lengths.h>
#include <igl/infinite_cost_stopping_condition.h>
#include <igl/shortest_edge_and_midpoint.h>

#include "mcf_skeleton.h" // Subclass declaration and utility functions

using namespace Eigen;
using ArrayXb = Eigen::Array<bool, Eigen::Dynamic,1>;

void MCFSkeleton::collapseShortEdges() {
    // Collapse shortest edges at their midpoint
    auto cost_and_placement = [this](int e, const MatrixXd &V, const MatrixXi &F, const MatrixXi &E, 
                                    const VectorXi &EMAP, const MatrixXi &EF, const MatrixXi &EI,
                                    double &cost, RowVectorXd &p) {
        // Default cost and placement strategy assigns cost as equal to edge length
        igl::shortest_edge_and_midpoint(e, V, F, E, EMAP, EF, EI, cost, p);
        // Assign infinite cost to edge longer than threshold
        if (cost > edge_TH) {
            cost = std::numeric_limits<double>::infinity();
        }
    };

    // Pre collapse: trivial callback to always attempt collapse
    int s, d; // Store original edge index
    auto pre_collapse = [&cost_and_placement, &s, &d, this](const Eigen::MatrixXd &V, const Eigen::MatrixXi &F, const Eigen::MatrixXi &E, const Eigen::VectorXi &EMAP, 
                        const Eigen::MatrixXi &EF, const Eigen::MatrixXi &EI, const igl::min_heap<std::tuple<double,int,int>> &Q,
                        const VectorXi &EQ, const MatrixXd &C, const int e) -> bool {
        
        Eigen::RowVectorXd p;
        double cost;
        cost_and_placement(e,V,F,E,EMAP,EF,EI,cost,p);
        if (is_fixed(E(e, 0)) || is_fixed(E(e, 1))) {
            cost = std::numeric_limits<double>::infinity();
            return false;  // Prevent the collapse
        }
        // Log variables for post collapse
        const int eflip = E(e, 0) > E(e, 1);
        s = eflip ? E(e, 1) : E(e, 0);  // Index of retained vertex
        d = eflip ? E(e, 0) : E(e, 1);  // Index of collapsed vertex

        return true;  // Allow the collapse
    };

    // Array track null vertices (to be removed)
    ArrayXb is_null_vertex = ArrayXb::Constant(V_temp.rows(), false);

    // Post collapse: override trivial callback to update poles and check for degeneracies
    auto post_collapse = [&is_null_vertex, &s, &d, this](const MatrixXd &V, const MatrixXi &F, const MatrixXi &E, const VectorXi &EMAP,
                        const MatrixXi &EF, const MatrixXi &EI, const igl::min_heap<std::tuple<double,int,int>> &Q,
                        const VectorXi &EQ, const MatrixXd &C, const int e, const int e1, const int e2,
                        const int f1, const int f2, const bool collapsed) -> void {

        if (collapsed) {
            // Determine the orientation of the edge collapse
            if (V.row(s) != V.row(d)) {
                std::cerr << "Error: Vertices s and d do not match after collapse." << std::endl;
            }
            is_null_vertex(d) = true; // Mark collapsed vertex 

            // Update correspondence vector
            VectorXi corr_update = (corr.array() == d).select(s, corr);
            corr_update = corr;

            // Reassign closest pole for retained vertex
            double d0 = (V_poles.row(s) - V.row(s)).norm();
            double d1 = (V_poles.row(d) - V.row(s)).norm();
            V_poles.row(s) = (d0<d1) ? V_poles.row(s) : V_poles.row(d);

            // check disk topology of one-ring neighbourhood around retained vertex
            int degenerate_count = 0;
            std::vector<std::vector<int>> A;
            igl::adjacency_list(F, A);
            for (int i = 0; i < A[s].size(); i++) {
                int neighbor = A[s][i];
                double mod_e = (V.row(s) - V.row(neighbor)).norm();
                if (mod_e < 0.1 * edge_TH) {
                    degenerate_count++;
                }
            }
            if (degenerate_count >= 2) {
                is_fixed(s) = true;
            }
        }
    };

    // Stop decimation if all remeaining edges have infinite cost
    igl::decimate_stopping_condition_callback stopping_condition;
    igl::infinite_cost_stopping_condition(cost_and_placement, stopping_condition);

    VectorXi uE_short;
    MatrixXd L;
    igl::edge_lengths(V_temp, F_temp, L); // Matrix
    utils::filter_edges_by_attribute(F_temp, L, std::less<double>(), edge_TH, uE_short);
    std::cout << "Number of short edges after contraction: " << uE_short.size() << std::endl;

    MatrixXd U;
    MatrixXi G;
    VectorXi J, I;
    bool clean_finish = igl::decimate(V_temp, F_temp, cost_and_placement, stopping_condition, pre_collapse, post_collapse, U, G, J, I);
    if (!clean_finish) {
        std::cerr << "Decimation did not finish cleanly." << std::endl;
    }
    assert(utils::is_watertight(F_temp));
    
    utils::audit_topology_changes(V_temp, U, F_temp, G);
    V_temp = U;
    F_temp = G;

    std::cout << "Number of null vertices after decimation: " << is_null_vertex.count() << std::endl;
    std::cout << "Number of fixed vertices after decimation: " << is_fixed.count() << std::endl;

    assert(is_fixed.size() == is_null_vertex.size());
    ArrayXb is_fixed_filtered(is_fixed.size()-is_null_vertex.count());
    Eigen::MatrixXd V_poles_filtered(V.rows(), V_poles.cols());

    int e = 0;
    for (int i = 0; i < is_null_vertex.size(); ++i) {
        if (!is_null_vertex[i]) { // Assuming 'true' means the row should be kept
            V_poles_filtered.row(e) = V_poles.row(i);
            is_fixed_filtered[e] = is_fixed[i];
            e++;
        }
    }
    assert(is_fixed_filtered.count() == is_fixed.count());
    assert(is_fixed.size() == V_poles_filtered.rows());
    is_fixed = is_fixed_filtered;
    V_poles = V_poles_filtered;
    std::cout << "Number of vertices after decimation: " << is_fixed.size() << std::endl;
}