#include <algorithm> 
#include <cassert>
#include <functional>
#include <Eigen/Core> 

// libigl includes
#include <igl/cat.h>                       
#include <igl/internal_angles.h>           
#include <igl/edge_lengths.h>             
#include <igl/edge_flaps.h>                
#include <igl/per_vertex_normals.h> 
#include <igl/dot_row.h>         

#include "mcf_skeleton.h" // Class declaration and utility functions

using namespace Eigen;
using ArrayXb = Eigen::Array<bool, Eigen::Dynamic, 1>; // Alias for a dynamic-sized array of booleans

void MCFSkeleton::splitBadTriangles() {
    // Lambda function to check if the edges to be split are valid
    auto valid_split_check = [this](const MatrixXi& uE, const VectorXi& uE_bad, VectorXi& uE_valid) -> bool {
        // Do not split edges with fixed vertices
        ArrayXb is_valid = !(is_fixed(uE(uE_bad, 0)).array() || is_fixed(uE(uE_bad, 1)).array());
        uE_valid.resize(is_valid.count());
        if (is_valid.count() == 0) {
            return false;
        }
        // Populate the output vector
        int e = 0;
        for (int i = 0; i < uE_bad.size(); ++i) {
            if (is_valid[i]) {
                uE_valid[e++] = uE_bad[i];
            }
        }
        return true; // Return true if any valid splits exist
    };

    // Lambda function to identify the vertices and poles to be projected
    auto project_vertices_and_poles = [this](const VectorXi& uE_batch, const MatrixXi& uE, 
                const VectorXi& uEC, const VectorXi& uEE, const MatrixXd& face_angles, 
                MatrixXd& V_projected, MatrixXd& poles_projected) -> void {
        // Get indices of the two directed edges associated with each unique edge
        VectorXi uEE_idx0 = uEC(uE_batch);
        VectorXi uEE_idx1 = uEE_idx0.array() + 1; // assumes 2 directed edges per unique edge
        
        // extract the half edge indices of each unique edge in the batch
        VectorXi E0_batch = uEE(uEE_idx0);
        VectorXi E1_batch = uEE(uEE_idx1);

        // Flatten angles column-wise to match half-edge indexing
        VectorXd angles_flat = Map<const VectorXd>(face_angles.data(), face_angles.size());

        // Retrieve the angles corresponding to the edges
        VectorXd alpha_w0 = angles_flat(E0_batch);
        VectorXd alpha_w1 = angles_flat(E1_batch);

        // Concatenate angles for validation
        MatrixXd alpha_pairs;
        igl::cat(2, alpha_w0, alpha_w1, alpha_pairs);
        // Extra check to ensure all angles are greater than the threshold
        if (!(alpha_pairs.rowwise().maxCoeff().array() > alpha_TH).all()) {
            std::cerr << "Error: Some edges in the batch do not correspond to bad triangles. Aborting operation." << std::endl;
            return;
        }

        // Get the vertices to project based on the comparison of angles
        VectorXi faces_flat = Eigen::Map<const VectorXi>(F_temp.data(), F_temp.size());
        VectorXi w0 = faces_flat(E0_batch);
        VectorXi w1 = faces_flat(E1_batch);
        VectorXi V_batch_idx = (alpha_w0.array() > alpha_w1.array()).select(w0, w1);
        
        // Set the vertices and poles to be projected
        MatrixXd points_to_project = V_temp(V_batch_idx, Eigen::all);
        MatrixXd poles_to_project = V_poles(V_batch_idx, Eigen::all);

        // Correct orientation of split edge to align with face order
        VectorXi e0_vec, e1_vec;
        e0_vec = (alpha_w0.array() > alpha_w1.array()).select(uE(uE_batch, 0), uE(uE_batch, 1));
        e1_vec = (alpha_w0.array() > alpha_w1.array()).select(uE(uE_batch, 1), uE(uE_batch, 0));

        MatrixXd A, B, AB, AP;
        VectorXd t;

        A = V_temp(e0_vec, Eigen::all); // Start of edge segment
        B = V_temp(e1_vec, Eigen::all); // End of edge segment
        
        // Compute projection factor t for vertices
        AB = B.array() - A.array();
        AP = points_to_project.array() - A.array();
        t = igl::dot_row(AB, AP).array() / igl::dot_row(AB, AB).array();

        // Clip t to the range [0, 1]
        t = t.cwiseMax(0.0).cwiseMin(1.0);

        // Project vertices
        V_projected = MatrixXd(A.array() + (t.asDiagonal() * AB).array());

        // Project poles onto the corresponding edges
        A = V_poles(e0_vec, Eigen::all);
        B = V_poles(e1_vec, Eigen::all);

        // Compute projection factor t for poles
        AB = B.array() - A.array();
        AP = poles_to_project.array() - A.array();
        t = igl::dot_row(AB, AP).array() / igl::dot_row(AB, AB).array();

        // Clip t to the range [0, 1]
        t = t.cwiseMax(0.0).cwiseMin(1.0);

        // Project poles
        poles_projected = MatrixXd(A.array() + (t.asDiagonal() * AB).array());
    };

    /** MAIN FUNCTION  */

    // Store the initial vertex and face matrices for comparison
    MatrixXd V_initial = V_temp;
    MatrixXi F_initial = F_temp;
    
    MatrixXi E, uE, EF, EI; // edge flap variables
    VectorXi EMAP, uEC, uEE; // edge map variables
    VectorXi uE_bad, uE_batch, remaining_edges, uE_valid; // vectors to track bad edges
    MatrixXd V_projected, poles_projected; // Matrix for new vertices and poles

    // Filter edges based on the internal angles (greater than threshold)
    MatrixXd face_angles;
    igl::internal_angles(V_temp, F_temp, face_angles);
    utils::filter_edges_by_attribute(F_temp, face_angles, std::greater<double>(), alpha_TH, uE_bad);
    std::cout << "Number of bad triangles: " << uE_bad.size() << std::endl;

    int iter = 0;
    while (uE_bad.size() > 0) {
        igl::edge_flaps(F_temp, uE, EMAP, EF, EI);
        // Validate potential splits and filter out edges with fixed vertices
        bool is_valid = valid_split_check(uE, uE_bad, uE_valid);
        std::cout << "Number of valid triangles to split: " << uE_valid.size() << std::endl;
        if (!is_valid) {
            break; // Stop if no valid splits remain
        }

        // Batch processing of non-adjacent edges
        utils::get_non_adjacent_edge_batch(uE_valid, EF, uE_batch);

        // Light assertion to check unique edges correspond to 2 half edges
        igl::unique_edge_map(F_temp, E, uE, EMAP, uEC, uEE);
        if ((uEC.unaryExpr([](int x) { return x % 2 != 0; })).any()) {
            std::cerr << "Number of faces shared by an edge is not exactly 2. Projecting logic may not hold." << std::endl;
            break;
        }

        // Project corresponding vertices and poles
        project_vertices_and_poles(uE_batch, uE, uEC, uEE, face_angles, V_projected, poles_projected);
        
        // Batch split non-adjacent bad triangles
        utils::split_non_adjacent_edges(V_temp, F_temp, E, EF, uE_batch, V_projected);

        // Resize and update poles
        V_poles.conservativeResize(V_poles.rows() + poles_projected.rows(), 3);
        V_poles.bottomRows(poles_projected.rows()) = poles_projected;

        // Update split tracking array
        is_split.conservativeResize(V_poles.rows());
        is_split.bottomRows(poles_projected.rows()).setConstant(true);

        // VectorXi IE;
        // igl::setdiff(uE_valid, uE_batch, remaining_edges, IE);
        // uE_valid = remaining_edges;
        // std::cout << "Remaining bad triangles (valid only): " << uE_valid.size() << ", after iteration: "<< iter << std::endl;

        igl::internal_angles(V_temp, F_temp, face_angles);
        utils::filter_edges_by_attribute(F_temp, face_angles, std::greater<double>(), alpha_TH, uE_bad);
        std::cout << "Number of bad triangles: " << uE_bad.size() << std::endl;

        iter++;
    }

    assert(V_temp.rows() == F_temp.maxCoeff() + 1);
    assert(utils::is_watertight(F_temp));

    // Finalize changes and update the meshs
    utils::audit_topology_changes(V_initial, V_temp, F_initial, F_temp);
}