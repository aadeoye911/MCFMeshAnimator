#include <Eigen/Core>
#include <Eigen/LU>
#include <Eigen/Sparse>

// libigl includes
#include <igl/cat.h>
#include <igl/cotmatrix.h>
#include <igl/invert_diag.h>
#include <igl/massmatrix.h>

#include "mean_curvature_flow.h" // Base class 

using namespace Eigen;

using ArrayXb = Eigen::Array<bool, Eigen::Dynamic,1>;

MeanCurvatureFlow::MeanCurvatureFlow(const MatrixXd& V, const MatrixXi& F, const MatrixXd& V_medial) 
    : V(V), F(F), V_medial(V_medial), V_temp(V), F_temp(F), V_poles(V_medial) { 

    is_fixed = ArrayXb::Constant(V.rows(), false); // tracking variable
    is_split = ArrayXb::Constant(V.rows(), false); // tracking variable
}

void MeanCurvatureFlow::performMeshContraction(){
    // Stack system constraints
    SparseMatrix<double> W_LL = W_L * L;
    SparseMatrix<double> W_LH, A;
    igl::cat(1, W_LL, W_H, W_LH);
    igl::cat(1, W_LH, W_M, A);

    MatrixXd b(3 * L.rows(), 3); 
    b.topRows(L.rows()) = MatrixXd::Zero(L.rows(), 3);
    b.middleRows(L.rows(), L.rows())= W_H * V_temp;
    b.bottomRows(L.rows()) = W_M * V_poles;

    Eigen::SparseMatrix<double> AtA = A.transpose() * A;
    Eigen::MatrixXd Atb = A.transpose() * b;

    std::cout << "V(t) dimensions: " << V_temp.rows() << "x" << V_temp.cols() << std::endl;
    std::cout << "Matrix AtA dimensions: " << A.rows() << "x" << A.cols() << std::endl;
    std::cout << "Matrix Atb dimensions: " << b.rows() << "x" << b.cols() << std::endl;

    Eigen::SparseLU<Eigen::SparseMatrix<double>> solver;
    solver.compute(AtA);
    if (solver.info() != Eigen::Success) {
        std::cerr << "SparseLU factorization failed!" << std::endl;
        return;
    }

    V_temp = solver.solve(Atb);
    std::cout << "V(t + 1) dimensions: " << V_temp.rows() << "x" << V_temp.cols() << std::endl;

    if (solver.info() != Eigen::Success) {
        std::cerr << "Solving failed!" << std::endl;
    }
}

void MeanCurvatureFlow::updateLaplacian(){
    Eigen::SparseMatrix<double> M, M_inv, C;
    igl::cotmatrix(V_temp, F_temp, C);
    igl::massmatrix(V_temp, F_temp, igl::MASSMATRIX_TYPE_VORONOI, M);
    M *= 2;
    igl::invert_diag(M, M_inv);
    L = M_inv * C;
}

void MeanCurvatureFlow::updateWeights(){
    SparseMatrix<double> I(V_temp.rows(), V_temp.rows());
    I.setIdentity();
    W_L = omega_L * I;
    W_H = omega_H * I;
    W_M = omega_M * I;

    for (int i = 0; i < V_temp.rows(); ++i) {
        if (is_fixed[i]) { // Assuming 'true' means the row should be kept
            W_L.coeffRef(i, i) = 0.0;
            W_H.coeffRef(i, i) = 1.0/zero_TH;
            W_M.coeffRef(i, i) = 0.0;
        }
        if (is_split(i)) {
            W_M.coeffRef(i, i) = 0.0;
        }
    }
}

void MeanCurvatureFlow::setParameters(double omega_L, double omega_H, double omega_M, double zero_TH) {
    this->omega_L = omega_L;
    this->omega_H = omega_H;
    this->omega_M = omega_M;
    this->zero_TH = zero_TH;
}