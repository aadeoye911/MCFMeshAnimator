
#include "utils.h"

using namespace Eigen;

using ArrayXb = Eigen::Array<bool, Eigen::Dynamic,1>;

namespace utils {

    void split_non_adjacent_edges(MatrixXd& V, MatrixXi& F, MatrixXi& uE, 
                            MatrixXi& EF, VectorXi& uE_batch, MatrixXd& V_new)
    {
        VectorXi faces_to_split, unique_faces;
        faces_to_split = EF(uE_batch, Eigen::all).reshaped();
        igl::unique(faces_to_split, unique_faces);

        if (faces_to_split.size() != unique_faces.size()){
            std::cerr << "Batch contains non-adjacent edges. Split aborted." << std::endl;
            return;
        }
        
        // Tile indices vector to match the matrix dimensions
        MatrixXi v1_tiled = uE(uE_batch, 0).replicate(1,3); // first vertex of edge
        MatrixXi v2_tiled = uE(uE_batch, 1).replicate(1,3); // second vertex of edge

        // Tile new vertices indices to match matrix dimensions
        VectorXi V_batch_idx = VectorXi::LinSpaced(uE_batch.size(), V.rows(), V.rows()+ uE_batch.size()-1);
        MatrixXi vN_tiled = V_batch_idx.replicate(1,3); // new vertices

        // Iterate over both adjacent faces (f = 0, 1) for each edge in the batch
        for (int f = 0; f < 2; ++f) {
            // Extract corresponding faces to split
            VectorXi F_batch_idx = EF(uE_batch, f); // Assumes mesh is watertight (no boundary edges)
            MatrixXi F_batch = F(F_batch_idx, Eigen::all);

            // Handle first subface: update original face replacing v1 with vN
            MatrixXi subface1 = (F_batch.array() == v1_tiled.array()).select(vN_tiled, F_batch);
            F(F_batch_idx, Eigen::all) = subface1;

            // Handle second subface: add additional face replacing v2 with vN
            MatrixXi subface2 = (F_batch.array() == v2_tiled.array()).select(vN_tiled, F_batch);
            F.conservativeResize(F.rows() + subface2.rows(), 3);
            F.bottomRows(subface2.rows()) = subface2;
        }
        // Append new vertices and subfaces
        V.conservativeResize(V.rows() + V_new.rows(), 3);
        V.bottomRows(V_new.rows()) = V_new;

        if (!igl::is_edge_manifold(F)) {
            std::cerr << "Mesh is not manifold after edge split" << std::endl;
        }
        if (!igl::is_vertex_manifold(F)) {
            std::cerr << "Mesh is not manifold after edge split" << std::endl;
        }
    }

    void get_non_adjacent_edge_batch(VectorXi& uE_indices, MatrixXi& EF, VectorXi& uE_batch) {
        std::unordered_set<int> unique_faces;
        ArrayXb batch_mask = ArrayXb::Constant(uE_indices.size(), false);
        
        for (int i = 0; i < uE_indices.size(); ++i) {
            bool add_to_batch = true;
            for (int j = 0; j < EF.cols(); ++j) {
                int face = EF(uE_indices[i], j);
                if (unique_faces.find(face) != unique_faces.end()) {
                    add_to_batch = false;
                    break;
                }
            }
            if (add_to_batch) {
                for (int j = 0; j < EF.cols(); ++j) {
                    unique_faces.insert(EF(uE_indices[i], j));
                }
                batch_mask[i] = true;
            }
        }
        // Allocate the exact required size for uE_batch
        uE_batch.resize(batch_mask.count());

        // Populate the output vector
        int e = 0;
        for (int i = 0; i < uE_indices.size(); ++i) {
            if (batch_mask[i]) {
                uE_batch[e++] = uE_indices[i];
            }
        }

        std::cout << "Batch size: " << uE_batch.size() << std::endl;
    }

    void get_edge_neighborhood(int e, MatrixXi& F, MatrixXi& uE, 
                            MatrixXi& EF, MatrixXi& EI, VectorXi& neighborhood)
    {
        if (neighborhood.size() != 4) {
            neighborhood.resize(4);
        }
        // v0 and v1 are the vertices of the edge
        int e0 = uE(e, 0); 
        int e1 = uE(e, 1);
        // v2 and v3 are the vertices opposite the edge
        int v0 = F(EF(e, 0), EI(e, 0)); 
        int v1 = F(EF(e, 1), EI(e, 1));
    
        neighborhood << e0, e1, v0, v1;
    }

    void get_vertex_valences(const MatrixXi& F, VectorXi& valences) {
        SparseMatrix<int> A;
        igl::adjacency_matrix(F, A);
        valences = MatrixXi(A).rowwise().sum();
    }

    void get_edge_midpoints(MatrixXd& V, MatrixXi& uE, VectorXi& uE_indices, MatrixXd& midpoints){
        midpoints.resize(uE_indices.size(), V.cols());
        igl::parallel_for(uE_indices.size(), [&](const int i) {
            int e = uE_indices(i);
            midpoints.row(i) = 0.5 * (V.row(uE(e, 0)) + V.row(uE(e, 1)));
        }, 1000);
    }

    bool is_watertight(const MatrixXi& F) {
        bool success = true;
        // Check if the mesh is vertex manifold
        if (!igl::is_vertex_manifold(F)) {
            std::cout << "Mesh is not vertex manifold" << std::endl;
            success = false;
        }
        // Check if the mesh is edge manifold
        if (!igl::is_edge_manifold(F)) {
            std::cout << "Mesh is not edge manifold" << std::endl;
            success = false;
        }
        // Check if the mesh has any boundary loops
        std::vector<std::vector<int>> boundary_loops;
        igl::boundary_loop(F, boundary_loops);
        if (!boundary_loops.empty()) {
            std::cout << "Mesh has an open boundary" << std::endl;
            success = false;
        }

        return success;
    }

    void audit_topology_changes(const MatrixXd& V_before, const MatrixXd& V_after, const MatrixXi& F_before, const MatrixXi& F_after){
        // Audit change in face count
        double F_delta = std::abs(F_after.rows() - F_before.rows());
        if (F_after.rows() > F_before.rows()) {
            std::cout << "Increase in face count: " << F_delta << std::endl;
        } 
        else if (F_after.rows() < F_before.rows()) {
            std::cout << "Decrease in face count: " << F_delta << std::endl;
        }
        else {
            std::cout << "No change in face count" << std::endl;
        }

        // Audit change in vertex count
        double V_delta = std::abs(V_after.rows() - V_before.rows());
        if (V_after.rows() > V_before.rows()) {
            std::cout << "Increase in vertex count: " << V_delta << std::endl;
        } 
        else if (V_after.rows() < V_before.rows()) {
            std::cout << "Decrease in vertex count: " << V_delta << std::endl;
        }
        else {
            std::cout << "No change in vertex count" << std::endl;
        }
    }
    void rotate_vector(RowVectorXi& vec) {
        int last_entry = vec(vec.size()-1);
        RowVectorXi segment = vec.head(vec.size() - 1);
        vec.tail(vec.size() - 1) = segment;
        vec(0) = last_entry;
    }
}