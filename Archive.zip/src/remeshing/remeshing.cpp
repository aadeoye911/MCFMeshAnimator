#include <iostream>
#include <igl/avg_edge_length.h>
#include "remeshing.h" // Class declaration and utility functions

using namespace Eigen;

Remeshing::Remeshing(const MatrixXd& V, const MatrixXi& F, double scale) 
    : V(V), F(F), V_temp(V), F_temp(F) {
    setTargetEdgeLength(scale);
}

void Remeshing::remesh(double lambda) {
    for (int i = 0; i < 6; ++i) {
        splitLongEdges();
        collapseShortEdges();
        flipOptimalEdges();
        tangentialSmoothing(lambda);
    }
    V_remeshed = V_temp;
    F_remeshed = F_temp;
}

void Remeshing::setTargetEdgeLength(double scale) {
    target_edge_length = scale * igl::avg_edge_length(V, F);
}