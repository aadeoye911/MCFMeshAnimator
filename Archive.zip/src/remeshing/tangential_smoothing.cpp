#include <iostream>
#include <Eigen/Core>
#include <Eigen/Sparse>

// libigl includes
#include <igl/adjacency_matrix.h>
#include <igl/massmatrix.h>
#include <igl/per_vertex_normals.h>
#include <igl/dot_row.h>

#include "remeshing.h"

using namespace Eigen;

void Remeshing::tangentialSmoothing(double lambda) {
    V_remeshed = V_temp;
    F_remeshed = F_temp;

    SparseMatrix<double> area, adj, weights, norm;
    Eigen::MatrixXd V_prev = V_temp;
    igl::adjacency_matrix(F_temp, adj);

    double epsilon = 1e-6;  // Convergence threshold
    int max_iterations = 10;  // Maximum number of iterations
    
    int iter = 0;
    while (iter < max_iterations) {
        // Compute area-weighted gravity centroid
        igl::massmatrix(V_temp, F_temp, igl::MASSMATRIX_TYPE_VORONOI, area);
        weights = area * adj;
        norm = MatrixXd(weights).colwise().sum().asDiagonal();
        MatrixXd gravity = norm.cwiseInverse() * weights * V_temp;

        igl::per_vertex_normals(V_temp, F_temp, N);
        MatrixXd D = gravity.array() - V_temp.array();
        VectorXd dot_product = igl::dot_row(N, D); // Result is (6002, 1)
        MatrixXd projection = D.array() - (dot_product.replicate(1, 3).array() * N.array());
        V_temp += lambda * projection;
        if ((V_temp - V_prev).norm() < epsilon) {
            break;  // Stop if changes are below the threshold
        }
        V_prev = V_temp;  // Update previous positions
        iter++;
    }
    std::cerr << "Converged after " << iter << " iterations" << std::endl;
    utils::audit_topology_changes(V_remeshed, V_temp, F_remeshed, F_temp);
}