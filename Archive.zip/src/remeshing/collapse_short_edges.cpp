#include <iostream>
#include <limits>
#include <functional>
#include <cmath>
#include <unordered_set>
#include <Eigen/Core>

// libigl includes
#include <igl/decimate.h>
#include <igl/edge_lengths.h>
#include <igl/shortest_edge_and_midpoint.h>
#include <igl/infinite_cost_stopping_condition.h>
#include <igl/decimate_callback_types.h>
#include <igl/decimate_trivial_callbacks.h>

#include "remeshing.h" // Class declaration and utility functions

using namespace Eigen;

void Remeshing::collapseShortEdges() {
    V_remeshed = V_temp;
    F_remeshed = F_temp;
    
    double min_length = 4.0 / 5.0 * target_edge_length;
    
    auto cost_and_placement = [&min_length, this](int e, const MatrixXd &V, const MatrixXi &F, 
            const MatrixXi &E, const VectorXi &EMAP, const MatrixXi &EF, const MatrixXi &EI, double &cost, RowVectorXd &p) {
        igl::shortest_edge_and_midpoint(e, V, F, E, EMAP, EF, EI, cost, p);
        // Only collapse short edges
        if (cost >= min_length){
            cost = std::numeric_limits<double>::infinity();
        }
    };

    igl::decimate_pre_collapse_callback pre_collapse;
    igl::decimate_post_collapse_callback post_collapse;
    igl::decimate_trivial_callbacks(pre_collapse, post_collapse);
    pre_collapse = [&cost_and_placement, &min_length, this](const Eigen::MatrixXd &V, const Eigen::MatrixXi &F, const Eigen::MatrixXi &E, const Eigen::VectorXi &EMAP, 
                        const Eigen::MatrixXi &EF, const Eigen::MatrixXi &EI, const igl::min_heap<std::tuple<double,int,int>> &Q,
                        const VectorXi &EQ, const MatrixXd &C, const int e) -> bool {
        
        // Update cost variable during collapse
        Eigen::RowVectorXd p;
        double cost;
        cost_and_placement(e,V,F,E,EMAP,EF,EI,cost,p);
        double length = (V.row(E(e,0))-V.row(E(e,1))).norm();
        if (length > min_length) {
            cost = std::numeric_limits<double>::infinity();
            return false;  // Prevent the collapse
        }
        return true;  // Allow the collapse
    };

    // Stop decimation if all remeaining edges have infinite cost
    igl::decimate_stopping_condition_callback stopping_condition;
    igl::infinite_cost_stopping_condition(cost_and_placement, stopping_condition);

    VectorXi J, I;
    bool clean_finish = igl::decimate(V_remeshed, F_remeshed, cost_and_placement, stopping_condition, pre_collapse, post_collapse, V_temp, F_temp, J, I);
    if (!clean_finish){
        std::cerr << "Decimation did not finish cleanly. Refine stopping condition." << std::endl;
    }
    assert(utils::is_watertight(F_temp));

    utils::audit_topology_changes(V_remeshed, V_temp, F_remeshed, F_temp);
}