#include <iostream>
#include <vector>
#include <cassert>
#include <algorithm>  // For std::sort
#include <utility> 
#include <Eigen/Core>

// libigl includes
#include <igl/edge_flaps.h>
#include <igl/parallel_for.h>

#include "remeshing.h" // Class declaration and utility functions

using namespace Eigen;

using ArrayXb = Eigen::Array<bool, Eigen::Dynamic, 1>; // Alias for a dynamic-sized array of booleans

void Remeshing::flipOptimalEdges() {
    V_remeshed = V_temp;
    F_remeshed = F_temp;

    auto flip_edge = [this](int e, const VectorXi& N_edge, const MatrixXi& EF, const MatrixXi& EI) -> void {
        // endpoint of input edge
        int e0 = N_edge(0);
        int e1 = N_edge(1);

        // endpoints of flipped edge
        int v0 = N_edge(2);
        int v1 = N_edge(3);

        // Corresponding face indices
        int f0 = EF(e, 0); // e0 -> e1
        int f1 = EF(e, 1); // e1 -> e0

        // Corner indices for each face
        int c0 = EI(e, 0); // v0 = F(f0, c0)
        int c1 = EI(e, 1); // v1 = F(f1, c1)

        RowVectorXi face0 = F_temp.row(f0); // [e0, e1, v0] in some cyclical order
        RowVectorXi face1 = F_temp.row(f1); // [v1, e1, e0] in some cyclical order
 
        // To flip face corresponding to f0 [e0 -> e1], map e0 -> v1
        RowVectorXi face0_flipped = (face0.array() == e0).select(v1, face0);
        
        // Permute by 1 to right so that e0 = F(f0, c0) corresponding to [v0 -> v1]
        utils::rotate_vector(face0_flipped);
        assert(face0_flipped(c0) == e1);

        // To flip face corresponding to f1 [e1 -> e0], map e1 -> v0
        RowVectorXi face1_flipped = (face1.array() == e1).select(v0, face1);
        
        // Permute so that e1 = F(f1, c1) corresponding to [v1 -> v0]
        utils::rotate_vector(face1_flipped);
        assert(face1_flipped(c1) == e0);
        
        // Update mesh
        F_temp.row(f0) = face0_flipped;
        F_temp.row(f1) = face1_flipped;
        assert(utils::is_watertight(F_temp)); // Ensure the result maintains manifold
    };

    MatrixXi E, uE, EF, EI;
    VectorXi EMAP;
    igl::edge_flaps(F_temp, uE, EMAP, EF, EI);
    
    VectorXi current_vals, target_vals;
    utils::get_vertex_valences(F_temp, current_vals);
    target_vals = VectorXi::Constant(F_temp.maxCoeff() + 1, 6);
    double initial_deviation = (current_vals - target_vals).cwiseAbs().sum();

    VectorXi N_edge(4), delta_val(4);
    delta_val << -1, -1, 1, 1;

    ArrayXb is_flipped = ArrayXb::Constant(uE.rows(), false);

    std::cout << "Iterating through edges to split" << std::endl;
    for (int e = 0; e < uE.rows(); e++) {
        utils::get_edge_neighborhood(e, F_temp, uE, EF, EI, N_edge);
        double deviation_before = (current_vals(N_edge) - target_vals(N_edge)).cwiseAbs().sum();
        double deviation_after = (current_vals(N_edge) + delta_val - target_vals(N_edge)).cwiseAbs().sum();

        if (deviation_after < deviation_before) {
            flip_edge(e, N_edge, EF, EI);
            current_vals(N_edge) += delta_val;
            igl::edge_flaps(F_temp, uE, EMAP, EF, EI);
            is_flipped(e) = true;
        }
    }

    std::cout << "Flipped count: " << is_flipped.count() << ". Total edges: " << uE.rows() << std::endl;

    double final_deviation = (current_vals - target_vals).cwiseAbs().sum();
    std::cout << "Total deviation before: " << initial_deviation << ". Total deviation after: " << final_deviation << std::endl;
}