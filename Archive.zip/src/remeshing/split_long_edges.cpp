#include <functional>
#include <cmath>
#include <cassert>
#include <Eigen/Core>

// libigl includes
#include <igl/edge_lengths.h>
#include <igl/edge_flaps.h>
#include <igl/is_edge_manifold.h>
#include <igl/setdiff.h>

#include "remeshing.h" // Class declaration and utility functions

using namespace Eigen;

void Remeshing::splitLongEdges() {
    V_remeshed = V_temp;
    F_remeshed = F_temp;
    
    MatrixXi uE, EF, EI;
    VectorXi EMAP, uE_long, uE_batch, remaining_edges;
    MatrixXd L, V_new;
    
    double max_length = 4.0 / 3.0 * target_edge_length;
    igl::edge_lengths(V_temp, F_temp, L); // Matrix
    utils::filter_edges_by_attribute(F_temp, L, std::greater<double>(), max_length, uE_long);
    std::cout << "Number of long edges: " << uE_long.size() << std::endl;

    // Iteratively perform edge split on batches of non-adjacent edges
    int iter = 0;
    while (uE_long.size() > 0) {
        igl::edge_flaps(F_temp, uE, EMAP, EF, EI);

        // Batch filter to prevent simulatenous modification of adjacent edges (and faces)
        utils::get_non_adjacent_edge_batch(uE_long, EF, uE_batch);
 
        // Compute corresponding batch of new midpoint vertices
        utils::get_edge_midpoints(V_temp, uE, uE_batch, V_new);
        
        // Perform batch split
        utils::split_non_adjacent_edges(V_temp, F_temp, uE, EF, uE_batch, V_new);

        VectorXi IE;
        igl::setdiff(uE_long, uE_batch, remaining_edges, IE);
        uE_long = remaining_edges;
        std::cout << "Remaining long edges: " << uE_long.size() << ", after iteration: "<< iter << std::endl;

        iter++;
    }

    assert(V_temp.rows() == F_temp.maxCoeff() + 1);
    assert(utils::is_watertight(F_temp));
    
    // Audit changes and update
    utils::audit_topology_changes(V_remeshed, V_temp, F_remeshed, F_temp);
}